/* Name: Maricruz Tolosa Amaya
 * Net ID: mtolosaa
 * ID#: 29988518
 * CSC 172 Project#3
 * Lab: MW 2:00-3:15
 * 
 */

This is my submission for Project#3. It will display the maps for UR, Monroe county and New York state. Paths are highlighted red if the shortest path between two points is wanted. It will print the path as well as shown. The runtime for this program is really small and it dependent on edges and vertex. The more there are, the longer it will take, like when using nys.txt. 

Files submitted: 
Adjacents.java
Draw.java
Edge.java
Test.java
Vertex.java
Output.txt
monroe.txt
ur.txt
nys.txt

How to run this code is detailed in Output.txt, as stated in the lab write-up.