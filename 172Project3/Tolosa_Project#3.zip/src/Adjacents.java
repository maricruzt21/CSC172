/* Name: Maricruz Tolosa Amaya
 * Net ID: mtolosaa
 * ID#: 29988518
 * CSC 172 Project#3
 * Lab: MW 2:00-3:15
 * 
 */

public class Adjacents {
	public Vertex v;
	public double w;
	//construct adjacents from vertex and weight
	public Adjacents(Vertex v, double w){
		this.v = v;
		this.w = w;
	}
}
