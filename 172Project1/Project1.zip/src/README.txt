/* Name: Maricruz Tolosa Amaya
 * Net ID: mtolosaa
 * ID#: 29988518
 * CSC 172 Project#1
 * Lab: MW 2:00-3:15
 * 
 */

This project deals with creating a Postfix calculator. 
The program gets the information from the text file and adds the input to a String array. From then, it is parsed and converted to postfix string and calculated. 

List of Files: 
Queue
QueueInterface
QueueList 
QueueListInterface
QueueNode
Stack
StackInterface
StackList
StackListInterface
StackNode
InfixtoPostfix
Postfix
Test