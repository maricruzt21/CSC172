/* Name: Maricruz Tolosa Amaya
 * Net ID: mtolosaa
 * ID#: 29988518
 * CSC 172 Lab # 6
 * Lab: MW 2:00-3:15
 * 
 */

public class StackNode<T> {
	public T data;
	public StackNode<T> next;
}
 