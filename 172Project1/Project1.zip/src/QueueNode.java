/* Name: Maricruz Tolosa Amaya
 * Net ID: mtolosaa
 * ID#: 29988518
 * CSC 172 Project#1
 * Lab: MW 2:00-3:15
 * 
 */

public class QueueNode<T>{
	
	public T data; 
	public QueueNode<T> next;
	public QueueNode<T> previous;
}
