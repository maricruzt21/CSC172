/* Name: Maricruz Tolosa Amaya
 * Net ID: mtolosaa
 * ID#: 29988518
 * CSC 172 Project#1
 * Lab: MW 2:00-3:15
 * 
 */

public interface StackInterface<T> {
	public boolean isEmpty();
	public void push(T x);
	public T pop();
	public T peek();
}
