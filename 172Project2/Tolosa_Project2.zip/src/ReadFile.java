
public class ReadFile {
	private String path;
	
	public ReadFile(String filePath) {
		path = filePath;
	}
	
	
}
